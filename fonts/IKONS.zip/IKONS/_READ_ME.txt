
IKONS

300 FREE vector icons from Piotr Kwiatkowski.


You are free to use these icons for personal and commercial work without obligation of payment or attribution. While attribution is optional, it is always appreciated. The icons may be altered, cropped or otherwise modified or manipulated for your needs.
        
Making modifications or alterations to any of the icons does not free you to then sell, license or distribute them to anyone else. The redistribution of any of the icons files as a standalone package is strictly prohibited. You may not redistribute or sell these icon set on any other website or source.
        
The IKONS are property of Piotr Kwiatkowski and are protected by copyright laws and international treaty provisions. Intellectual property rights are not transferred with the download of the icons. All brand icons are trademark of their respective owners.

Piotr Kwiatkowski shall not be liable to any kind of damage arising from the use of IKONS.
        
If you use IKONS in your Dribbble shot, please add a "ikons" tag.
        
Thank you.


Piotr Kwiatkowski

piotrkwiatkowski.co.uk

twitter.com/p_kwiatkowski

dribbble.com/p_kwiatkowski

behance.net/piotrkwiatkowski


